<div class="container-fluid banner-sup ">
	<div class="row">
		<img src="<?= base_URL()?>assets/img/mini-header-suites1.jpg" class="img-fluid" alt="">
	</div>
</div>
<div class="container">
	<div class="row d-flex justify-content-center m-t-50 m-b-50">
		<div class="col-12 col-md-10 col-lg-10 col-xl-10 text-justify text-blue text-2 descrip">
			<h4><?= $textsuitep->TextoPrincipal?></h4>
 		</div>
 		<div class="col-7 col-md-4 col-lx-4 col-lg-4 text-center m-t-50">
 			<img src="<?= base_URL()?>assets/img/ornamento_habitaciones-dorado.svg" class="img-fluid" alt="">
 		</div>
	</div>
</div>
